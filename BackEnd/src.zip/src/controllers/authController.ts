import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/userModel";

const JWT_SECRET: string = "mySuperSecretKey123!"; // JWT Secret key

// Signup controller logic
export const signup = async (req: Request, res: Response): Promise<void> => {
  try {
    const { first_name, last_name, dob, email, phone_number, password } =
      req.body;

    // Check if user already exists
    const existingUser = await User.findByEmail(email);
    if (existingUser) {
      res.status(400).json({ message: "Email already exists" });
      return; // No further code should run after sending the response
    }

    // Hash Password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new user
    await User.createUser(
      first_name,
      last_name,
      dob,
      email,
      phone_number,
      hashedPassword
    );
    res.status(201).json({ message: "User registered successfully" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};

// Login controller logic
export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    const user = await User.findByEmail(email);
    if (!user) {
      res.status(400).json({ message: "Invalid email or password" });
      return; // No further code should run after sending the response
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      res.status(400).json({ message: "Invalid email or password" });
      return; // No further code should run after sending the response
    }

    // Sign JWT Token
    const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "1h" });

    res.status(200).json({ message: "Login successful", token });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
};
