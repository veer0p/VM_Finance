import express from "express";
import {
  getUserDetails,
  updateUserDetails,
} from "../controllers/userController";

const router = express.Router();

// Get user details
router.get("/:id", getUserDetails);

// Update user details
router.put("/:id", updateUserDetails);

export default router;
