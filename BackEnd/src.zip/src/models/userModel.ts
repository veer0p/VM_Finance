import { Pool } from "mysql2/promise";
import pool from "../config/db";

class User {
  // ✅ Find a user by email
  static async findByEmail(email: string): Promise<any> {
    const [rows]: any = await pool.query(
      "SELECT * FROM users WHERE email = ?",
      [email]
    );
    return rows[0];
  }

  // ✅ Find a user by ID (fix for findById error)
  static async findById(id: number): Promise<any> {
    const [rows]: any = await pool.query("SELECT * FROM users WHERE id = ?", [
      id,
    ]);
    return rows[0]; // Return the user or null if not found
  }

  // ✅ Update user details (fix for update error)
  static async updateUser(id: number, updatedData: any): Promise<any> {
    const fields = Object.keys(updatedData)
      .map((key) => `${key} = ?`)
      .join(", ");

    const values = Object.values(updatedData);
    values.push(id); // Add ID as last parameter for WHERE clause

    const [result]: any = await pool.query(
      `UPDATE users SET ${fields} WHERE id = ?`,
      values
    );

    return result;
  }

  // ✅ Create a new user
  static async createUser(
    first_name: string,
    last_name: string,
    dob: string,
    email: string,
    phone_number: string,
    password: string
  ): Promise<any> {
    const [result]: any = await pool.query(
      "INSERT INTO users (first_name, last_name, dob, email, phone_number, password) VALUES (?, ?, ?, ?, ?, ?)",
      [first_name, last_name, dob, email, phone_number, password]
    );
    return result;
  }

  // ✅ Get all users
  static async getAllUsers(): Promise<any> {
    const [rows]: any = await pool.query(
      "SELECT id, first_name, last_name, email, phone_number, createdAt, updatedAt FROM users WHERE deleted = false"
    );
    return rows;
  }
}

export default User;
